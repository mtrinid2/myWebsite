import logo from './logo.png'
import menu_logo from './menu_logo.png'
import dot from './dot.png'
import facebook from './facebook.png'
import instagram from './instagram.png'
import select from './select.png'
import myphoto from './myphoto.jpg'

export const assets = {
    logo,
    menu_logo,
    dot,
    facebook,
    instagram,
    select,
    myphoto
}